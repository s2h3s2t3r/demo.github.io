# Circles and lines

A Pen created on CodePen.io. Original URL: [https://codepen.io/sfi0zy/pen/GREPMdL](https://codepen.io/sfi0zy/pen/GREPMdL).

https://qna.habr.com/q/1052944